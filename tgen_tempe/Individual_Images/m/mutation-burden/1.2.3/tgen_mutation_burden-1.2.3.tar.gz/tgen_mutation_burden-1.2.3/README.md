
## TGen Mutation Burden Tool

## Description
This tool calculates the << Mutation Burden per Million Base >> of a Patient's Tumor

#### Some background history
The Community also call that type of calculation the `Tumor Mutational Burden` hence `TMB` for short. 
We call it `TGen Mutation Burden` in reference to the fact that the calculation of the `TMB` is (and was) TGen-specific.
It may be confusing when using the acronym but whatever the meaning of `TMB` both meaning of the T are here, in this repo, interchangeable with the intent of calculating the `Mutation Burden` of a `case` sample


## Installation  
1. Clone the repository  
2. Make the file  **```tgen_mutation_burden.sh```**  executable [```chmod u+x```] or prepend it with the ```bash``` command
3. Run the file **```tgen_mutation_burden.sh```**

  
____
## Inputs [ files and Options ]  
The tool requires four (4) mandatory files:  
1. The **FILTERED** list of somatic variants called within the TARGET space [ VCF file ]  
2. The Constitutional (or normal) BAM file used in variant calling  
3. The Case (or tumor) BAM file used in variant calling   
4. The TARGET file in BED format  [ **OR** a REGION information for advanced users only (see options below) ] 

The tools has also optional arguments:
1. Other inputs may be added, see the description of **options** below
2. Other options may be modified to optimize the computation  

  
____
## Output  
The Mutation Burden is outputted in a file with a structure similar to the Picard's tool output metrics file  
**_Example_**  
\#\# METRICS CLASS  &nbsp;&nbsp;&nbsp;&nbsp; 
MutationsCount  &nbsp;&nbsp;&nbsp;&nbsp;   Coverage  &nbsp;&nbsp;&nbsp;&nbsp;   MutationBurdenPerMillionBase  &nbsp;&nbsp;&nbsp;&nbsp;   MinReadDepth  &nbsp;&nbsp;&nbsp;&nbsp
;   TumorMinReadDepthPerStrand  &nbsp;&nbsp;&nbsp;&nbsp;   MinBaseQual  &nbsp;&nbsp;&nbsp;&nbsp;   MinMapQual  &nbsp;&nbsp;&nbsp;&nbsp;   NBam  &nbsp;&nbsp;&nbsp;&nbsp;   TBam  &nbsp;&nbsp;&nbsp
;&nbsp;   region  &nbsp;&nbsp;&nbsp;&nbsp; region_name &nbsp;&nbsp;&nbsp;&nbsp; dbsnp_pct_in_region    &nbsp;&nbsp;&nbsp;&nbsp;   SAMPLE   &nbsp;&nbsp;&nbsp;&nbsp;  LIBRARY   &nbsp;&nbsp;&nbsp
;&nbsp;  READ_GROUP
230   &nbsp;&nbsp;&nbsp;&nbsp;     97457645  &nbsp;&nbsp;&nbsp;&nbsp;   2.35999956699138000000  &nbsp;&nbsp;&nbsp;&nbsp;   10  &nbsp;&nbsp;&nbsp;&nbsp;   1  &nbsp;&nbsp;&nbsp;&nbsp;   5  &nbsp
;&nbsp;&nbsp;&nbsp;   5  &nbsp;&nbsp;&nbsp;&nbsp;   NormalBAM.bam  &nbsp;&nbsp;&nbsp;&nbsp;   TumorBAM.bam  &nbsp;&nbsp;&nbsp;&nbsp;   14:0-15000000 &nbsp;&nbsp;&nbsp;&nbsp;  p_arm &nbsp;&nbsp
;&nbsp;&nbsp;  0.858569   &nbsp;&nbsp;&nbsp;&nbsp;  mySampleName   &nbsp;&nbsp;&nbsp;&nbsp;  myLibraryName    &nbsp;&nbsp;&nbsp;&nbsp;   myReadGroup    


##_IMPORTANT NOTES_: 
**_NOTE about inputs:_**  
1. This tool will use ALL the mutations listed in the `VCF` file for the count of the mutationBurden. 
2. Therefore, the VCF file **MUST** already contains the Mutations that you only want to include in the count of the mutation burden calculation. If you want to exclude some of the Mutations from the count, you have to provide the **Filtered** `VCF` file to the tool.    [ _For instance, if you want the mutation burden for the NON-SYNONYMOUS variants only, you will need to provide a vcf containing only non-synonymous variants_].  
3. **ALL** the contigs present in the `VCF` **MUST** also be present or represented in the provided `regions file` (whether it is a bed file or the equivalent of a p-q-arms like-file)  AND **MUST** also match the contig names found in the BAM/CRAM files;  

**_NOTE about intermediate bed file output:_**  
If you used the option ```--keep-unflt-outfile``` and therefore want to keep the compressed bed output file with all callable positions, here a description of the 6 columns in that file:
chr &nbsp;&nbsp;&nbsp;&nbsp; position &nbsp;&nbsp;&nbsp;&nbsp; Nbam_ForwardSrandCoverage &nbsp;&nbsp;&nbsp;&nbsp; Nbam_ReverseStrandCoverage  &nbsp;&nbsp;&nbsp;&nbsp; Tbam_ForwardStrandCoverage  &nbsp;&nbsp;&nbsp;&nbsp; Tbam_ReverseStrandCoverage   

  
____
## Requirements  
- 5 cpus minimum
- samtools   version 1.10 or greater MUST be in Your PATH  
- bgzip   version 1.7 or greater MUST be in Your PATH  
- tabix   version 1.7 or greater MUST be in Your PATH  
- bedtools version 2.29 or up MUST be in your PATH
- parallel [only if using the `--gnu-parallel-jobs` option]  
- Rscript 3.2.1 or greater MUST be in your PATH  
   --> Packages Required in R: 
 1. ggplot2  
 2. optparse  

____
## Usage & Options:  

#### List of available Options &nbsp;&nbsp; [M = Mandatory, O = Optional ]  

##### <---- mandatory options ---->  
**--vcf)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; VCF file with somatic variants [M]  
**--nbam)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Constitutional or Normal BAM/CRAM file [M]  
**--tbam)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Case or Tumor BAM/CRAM file [M]  
**--bed) or --region)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; At least ONE of these two options MUST be provided [M]  
  
##### <---- optional ----->  
**--bed)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; BED file representing the TARGETS Regions; If `--region` is NOT provided, then the bed file MUST be provided  [O]  
**--mindepth)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Minimum read depth for both BAMs/CRAMs at each positions --> Callable Space [O, Default value is 10]  
**--min-read-per-strand)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Minimum read depth for each Strand for Case/Tumor BAM at each positions [O, Default value is 1]  
**--min-base-qual)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Minimum base quality to keep the read when samtools depth is run [O, Default value is 5]  
**--min-map-qual)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Minimum Mapping quality to keep the read  when samtools depth is run [O, Default value is 5]  
**--outprefix)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Provide a prefix name to temporary and/or default output filenames [O, default is NULL]  
**--outfile)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Provide final stats outfilename full or relative path [O, default is NULL]  

**--skip-plot)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Flag that will skip making the plot when `--pqarms` option used [O, default is "no"]  
**--keep-unflt-outfile)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If you need to keep the unfiltered samtools depth's output file, use this option; Useful to get the depth in given regions (or bed) [O, Default is 'no' ] 
 
**--pipeline)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Flag that will create an output file formatted specifically for author's company pipeline [O, default is "no"]  
**--sample**  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; samplename that will be added to the output file in column `SAMPLE`
**--library**  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; library name that will be added to the output file in column `LIBRARY`
**--rg**  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; read_group name that will be added to the output file in column `READ_GROUP`  
 
**--force)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If the contigs between the two bam files do not perfectly match both at the name and size levels, the script will stop; be aware that using this option to force the run that might generate wrong calculi. Use at your own risk unless you are sure that the contigs difference will not impact the Mutation Burden calculation, such as the difference may be in alternate contigs not present in the VCF; [O, Default is 'no'] 
 
**--pqarms)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; provide a 2-columns FILE with column 1 as the coordinates (1:0-121535434) of the arms and the column 2 as the name of the arms (such as p or q
); see file examples;   __**Note**__: Plots are generated only if `--pqarms` options is used ; Otherwise No plot , just a `*stats.txt` file  
**--region)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [for DEBUGGING use only ] You may provide a region formatted as follow chr1:100000-200000 ; coordinates value are inclusive here; this will speed up the output while testing if you modified the current script ; the region will only be used with the samtools view to limit the searching region space in bam/cram files ; the BED file, if provided, will **NOT** be used; This  option helps for debugging by reducing the space;  [O, Default is NULL]  
**--region-name)**  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [for DEBUGGING use only ] INTERNAL Variable;  Only used if `--pqarms` is provided [O, Default is NULL]  
**--pct-dbsnp)**    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; INTERNAL Variable;  Only used if `--pqarms` is provided and if file from option `--pqarms` contains dbsnp percentage in the third column\t [O, Default is NULL]  
**--do-not-add-dbsnp-pct-to-plot)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; enable plotting the percentage percentage of `dbsnp` in given regions ; required `--pqarms` option with a 3-column file provided to `--pqarms` option    

<br>
  
##### <---- Advanced Users Only ----->  
<----- USE ONLY when `--pqarms` option is enabled ----> 

**-j|--gnu-parallel-jobs) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is for more advance users; this option will require LOTS of CPUS if value if greater than 1 ; see README to learn about how many cpus total will be require [O, Default is 1 ]**  
**-t|--threads)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Use with CAUTION ;  May help if using CRAM file(s) ; [O, Default is 1] ;  
If you want to save 5 minutes to your run you may use up to 3 or 4 threads per `samtools view` command ; this will therefore increase the need of cpus to 10 to 16 cpus to run this script, respectively;   
 _Note: if users gives more than 4, it is set back to 4 (unless it is demonstrated to the author that in some system, samtools uses more than 4 cpus to read either BAM or CRAM faster and save a significantly amount of runtime)_
 

##### <---- debugging -----> 
**--verbose)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; print the samtools commands ; print the content of the file with stats ; help in debugging [O, Default is 'no']  
##### <---- help ----->  
**-h|--help)** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; print all options and exit  

 
____
## HOW TO RUN TMB Tool  

##### some Tips  
- First create a temporary folder, `cd` into it and launch the main script from there.  
- Inputs can be provided as full or relative path as long as the tool will see the files

### **IMPORTANT NOTES**  
1. If you provide a specific TARGET region using the option `--region`, the BED file is not necessary  
2. region option should have the exact following format: chr:posStart-posEnd  ; postEnd may be equal to posStart but should be present in any case. 
3. If no coverage found, or no mutations found in provided regions, the output file shows `0 0 NA` in the columns _mutationCount_, _coverage_ and _mutationBurden_ respectively  
4. output filename is based on the combination of the PREFIX if any provided and the basename of the Tumor BAM/CRAM file like this: 
`${OUTPREFIX}${TUMOR_BAM_BASENAME}.coverage.mutation_burden.stats.txt`  ;  if no prefix given, it will be just `${TUMOR_BAM_BASENAME}.coverage.mutation_burden.stats.txt`
5. `BAM` or/and `CRAM` files can be used with this tool.
6. To enable parallel run, `--pqarms` MUST be provided. It can be the same regions provided with `--bed` option but with appropriate format; Using the option `--gnu-parallel-jobs` without using
 `--pqarms` is useless. [Note: Future Implementation will get rid of this restriction and remove the use of `--pqarms` ; An annotated bed file will be used instead]
7. All the files created by this script will be written in the directory where the main script `tgen_mutation_burden.sh` was executed except for the output stats file if given with the option `--outfile`
  
____
## _Examples:_  
 
##### 1) normal usage  
`bash tgen_mutation_burden.sh --bed \${MYBED} --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM}  `
##### 2) normal usage with extra options  
`bash tgen_mutation_burden.sh --bed \${MYBED} --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --prefix 'anyStringHere_withOnlyAlphaNumericCharacter' ` 
##### 3) if you want to keep the output from samtools depth command, use --keep-unflt-outfile option  
`bash tgen_mutation_burden.sh --bed \${MYBED} --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --keep-unflt-outfile option`  
##### 4) if you want to use different minimum values for read depth and qualities ...  
`bash tgen_mutation_burden.sh --bed \${MYBED} --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --keep-unflt-outfile option --mindepth 20 --min-read-per-strand 2 --min-base-qual 20 --min-map-qual 20 ` 
##### 5) if you want to use only a specific region without providing a bed file
`bash tgen_mutation_burden.sh --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --region 1:1000000-2000000  `
##### 6) if you want to get the mutation Burden per p and q arms of the chromosomes, provide a 2-column tabulated file with column #1 as arm's coordinate and column #2 as the name of that region  
`bash tgen_mutation_burden.sh --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --pqarms \${MY_PQ_ARM_FILE}`  
##### 7) same as Example #6 with dbsnp percentage NOT added to the plot
`bash tgen_mutation_burden.sh --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --pqarms \${MY_PQ_ARM_FILE} --do-not-add-dbsnp-pct-to-plot` 
##### 8) debugging usage  
`bash tgen_mutation_burden.sh --bed \${MYBED} --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --region 1:1000000-2000000 --verbose  `

##### ** Advanced Users **  
###### --threads and/or --gnu-parallel-jobs  usage
The option `gnu-parallel-jobs` is only used to decrease the runtime by splitting the workload according to the regions given in the bed file; `1 region == 1 job`  

For each region, 5 cpus are required because we run 5 `samtools` commands simultaneously within the `main script` hence the following **WARNING!**:   a "normal usage" ALREADY consumes 5 cpus at 100% (based on tests performed in 2017). The bash script `tgen_mutation_burden.sh` runs,  by default, with `threads=1` and `gnu-parallel-jobs=1`; so you need to calculate  consequences of  modifying  default values of  threads  and  parallel;    
For example, maximumn total number of **CPUS needed** per instance of `tgen_mutation_burden.sh` job is:  5 x number of _threads_ x number of _gnu parallel jobs_  ;  
Numerical examples: 5x1x1=5 [default usage];  5x2x2=20 ;  5x1x4=20 ; 5x3x1=15

#### Tips
- if `--pqarms` option is **used**   : Recommended, threads is 1 and gnu-parallel-jobs is 4 [total cpu needed for job: 20]
- if `--pqarms` option is **not used**: Recommended, threads is 3  and gnu-parallel-jobs is 1 [total cpu needed for job: 15]   

 
Example of a run `tgen_mutation_burden.sh` with `--pqarms` in an optimized way with a trade-off between speed and runtime [ ~ 30 minutes ]  
##### 9) same as Example #7 but with --gnu-parallel-jobs enabled  
```bash tgen_mutation_burden.sh --vcf \${MYVCF} --nbam \${MYNBAM} --tbam \${MYTBAM} --pqarms \${MY_PQ_ARM_FILE} --do-not-add-dbsnp-pct-to-plot --threads 1 --gnu-parallel-jobs 4```   
[this will use 20 cpus (5x1x4) ]
____
##### 10) author company special pipeline
` tgen_mutation_burden.sh --bed bed_file_regions_example_GRCH38_with_chr_prefix_chr1_22XY.bed --vcf MYSAMPLENAME.bwa.manta.somaticSV.pass.vcf.gz --nbam CASE.bwa.bam --tbam
 Constitutional.bwa.cram  --outprefix ANY_PREFIX_for_TEMP_files --sample MYSAMPLENAME --library KKKKKKK --rg MyRG --pipeline --outfile  /path/to/OUTPUT_FILENAME --verbose  `

## Citation
Translational Genomics Research Institute (TGen) Mutation Burden. 
https://github.com/tgen/tgen_mutation_burden/

____
For issues, questions or bugs report, please open an issue on github.
____

Thanks  
**The TGen Mutation Burden Team**  

