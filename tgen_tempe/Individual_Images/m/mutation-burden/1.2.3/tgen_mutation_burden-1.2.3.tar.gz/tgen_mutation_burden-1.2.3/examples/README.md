### What are the example files? 

- *chromosomes_arms_coordinates_pq.txt*	: Example of file with the p and q arm defined; This is just an example or regions; your regions can be whatever you want as long as the region is greater than 100bp 
- *mut_burden.per_arm.w_dbsnp_pct.png*	: This is an example of plot output you would get when using the file with regions p and q arms defined 
- *simple_flowchart.png* : This is an image representing how the tool works in a nutshell 



### how was generated the chromosome_arms_coordinates.txt file:

We got the file from UCSC table browser (output was URL : "https://genome.ucsc.edu/cgi-bin/hgTables?hgsid=936753879_GfNRAvCmYAMi6aTgPH7bO2aBwXsm&boolshad.hgta_printCustomTrackHeaders=0&hgta_ctName=tb_cytoBand&hgta_ctDesc=table+browser+query+on+cytoBand&hgta_ctVis=pack&hgta_ctUrl=&fbQual=whole&fbUpBases=200&fbDownBases=200&hgta_doGetBed=get+BED" )  
The output file created was: `GRCh38_Cytobands.bed` 
Then the file got processed as follow:

```
awk '$4!="."' GRCh38_Cytobands.bed | head
awk '$4!="."' GRCh38_Cytobands.bed > GRCh38_Cytobands_with_pq.bed
awk '$4!="." {if($4 ~/p/) { FS=OFS="\t" ; print $1,$2,$3,$4,"p"} else { FS=OFS="\t" ; print $1,$2,$3,$4,"q"} } ' GRCh38_Cytobands_with_pq.bed > GRCh38_Cytobands_with_pq_for_merging.bed
bedtools groupby -i GRCh38_Cytobands_with_pq_for_merging.bed -g 5,1 -c 2,3 -o min,max | awk '{OFS="\t" ; print $0,$1}' | cut -f1 --complement > chromosomes_arms_coordinates_pq.bed
bedtools groupby -i GRCh38_Cytobands_with_pq_for_merging.bed -g 5,1 -c 2,3 -o min,max | awk '{OFS="\t" ; print $0,$1}' | cut -f1 --complement | sed 's/\t/:/ ; s/\t/-/' > chromosomes_arms_coordinates_pq_2cols.txt
```

Two files can then be used: the `BED` file or/and the `txt` file for the options `--bed` and `--pq-arms` respectively (for instance)  

Note: Plots are generated only if `--pqarms` options is used ; No plot otherwise, just a `*stats.txt` file is outputted


### GRCh38 File examples
#### Files
1. bed_file_regions_example_GRCH38_with_chr_prefix_chr1_22XY.bed
2. chromosomes_arms_coordinates_pq.bed
3. chromosomes_arms_coordinates_pq_2cols.txt
4. chromosomes_arms_coordinates_pq_dbSnp_3cols.txt
5. mut_burden.per_arm.w_dbsnp_pct.png
6. simple_flowchart.png

#### File description and some explanations about them
1. This `BED` file is an example of whole genome capture with only the main contigs
2. This `BED` file represents the p-q arms coordinates for GRCh38 in a bed format
3. This `txt` 2-column tabulated file represent the same data as in 2) but formatted for this tool when using the `--pqarms` option;   even though we call that `pqarms` because it was developed to
 plot the mutation burden within each arm of the chromosomes, actually, a file with any named regions could be used; the output bar plot will actually  represent these named regions as well
  ; example, a line like &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  **chr22:21995603-23057822 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; IgL**  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; would be valid and will be
   plotted as IgL region with associated value as any p-q arm line.  
4. same file as in 3), but a covariate has been added to column 3; Developped with dbSnp values in mind, but any other value could be specify here and later be plotted; see histogram plot file
 example `mut_burden.per_arm.w_dbsnp_pct.png`
5. Example of plot created when using the `--pqarms` option
6. Flowchart about the current tool steps to capture and calculate the **Mutation Burden** of a Tumor BAM/CRAM file  

 