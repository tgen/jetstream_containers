# tHReD
TGen Homologous Recombination Deficiency (HRD) Tool to calculate HRD score ala TGen.

## Outline



## Arguments
###-- required arguments --
  **-s SEG, --seg SEG**)  
  SEG file with non-overlapping segments (default: None)  

  **-g GENOMIC_REGIONS, --genomic-regions GENOMIC_REGIONS)**  
                        Genomic Regions File defining Centromere (required)
                        and optionally telomeres, p and q arms. NOTE: defined
                        regions MUST not overlap (default: None)  

###-- optional arguments --
  **-t TH_LOG2R, --th-log2r TH_LOG2R)**   
                        log2R Threshold value for considering a Deletion
                        (default: -0.1613) 

  **-m MINSIZE, --minsize MINSIZE)**  
                        Minimum size region for a Segment to be considered
                        into HRD score (default: 1000000)  

  **-j TH_PCT_OVERLAPPING, --th-pct-overlapping TH_PCT_OVERLAPPING)**  
                        Percentage of overlapping between arm and sum of
                        segements with deletions [allow to exclude deletion
                        being an entire arm for instance ] (default: 0.9)    

  **-d DIR_OUT, --dir-out DIR_OUT)**  
                        Output directory where the temp and results file will
                        be written (default is current directory) (default: '.')  

  **-o OUTFILE, --outfile OUTFILE)**  
                        output file where the score HRD will be saved into;
                        Can be relative or full path. We encourage you give a unique name in order to avoid overwriting conflicts if running several samples in the same output directory (default: 'hrd_scores.txt')  

  **--threads THREADS)**    
                        Number of cpus or threads (default: 1)  

  **-w CONTIGS, --contigs CONTIGS)**  
                        comma-separated list of contigs to use with the HRD
                        score; Contigs Must Exist in Seg file and Genomic
                        Region file; If None, list will be captured from SEG
                        file (default: '.')

 **-S SAMPLE, --sample SAMPLE)**  
                        Sample Name to add to the results output table
                        (default: '.')  

  **-i ID, --id ID)**   
  Kit Code or Any ID you want to add to the results
                        output table (default: '.')  

  **-e EXCLUDE_CONTIGS, --exclude-contigs EXCLUDE_CONTIGS)** 
                        comma-separated list of contigs to exclude from HRD
                        scores (default is "chrX,chrY,chrM")    

  **-k KARYO_FILE, --karyo-file KARYO_FILE)**  
                        Cytoband Information of the Genome [UCSC -->
                        table_browser --> Sequence & Mapping --> Chromosome
                        Band --> allFieldsFromSelectedtable --> getOuput
                        button ; default is karyo_file =
                        "examples/inputs/grch38_ucsc_cytobands.bed" (default: ../examples/inputs/grch38_
                        ucsc_cytobands.bed')  

  **-p, --plots)**  
  by default no plot will be created ; use --plots to
  enabled making plots (default: False)  
  

### Examples of "how to run"
```
1.  tHRed.py --help
2.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName  
3.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName --outfile hrd_scores.txt --dir-out relative/path/directory/whereOutputAreWritten
4.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName --outfile hrd_scores.txt --dir-out  
/full/path/directory/whereOutputAreWritten
5.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName --outfile /full/path/hrd_scores.txt --dir-out 
    /full/path/directory/whereOutputAreWritten --th-log2r -0.1613 --minsize 1000000 --th-pct-overlapping 0.90
6.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName --outfile /full/path/hrd_scores.txt --dir-out 
    /full/path/directory/whereOutputAreWritten --th-log2r -0.1613 --minsize 1000000 --th-pct-overlapping  0.90 --plots
7.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName --outfile /full/path/hrd_scores.txt --dir-out 
    /full/path/directory/whereOutputAreWritten --th-log2r -0.1613 --minsize 1000000 --th-pct-overlapping  0.90 --plots --exclude-contigs "chrX,chrY,chrM"
8.  tHRed.py --genomic-regions examples/inputs/genomic_coordinates_GRCh38_centros.bed --seg examples/inputs/seg_example.seg --sample UniqueName --outfile /full/path/hrd_scores.txt --dir-out 
    /full/path/directory/whereOutputAreWritten --th-log2r -0.1613 --minsize 1000000 --th-pct-overlapping  0.90 --plots --exclude-contigs "chrX,chrY,chrM" --id WGS
```

1. show the options for the tool
2. minimum recommended command line to use for running tHReD tool
3. best recommended command to run the tool; provides control over where the outputs files will be written
4. same as 3. but using full path for the dir-out
5. same as 4. with the options that most impact the outcome on the HRDscore besides inclusion and exclusion of contigs
6. by adding the `--plots` options, simple karyotypes will be drawn with the segments; red if above absolute value of th-log2r, green if below that value and black if between that value and its 
   absolute value counterpart
7. example of list to exclude contigs; by default we exclude chrX,chrY and chrM; Let us know if you would rather have a default value empty;
8. an ID can be used to annotate the HRD scores; this id can be any string; spaces will be strip out. The string must be provided in between quotes (simple or double); 


## Input and Output Files Examples  

You may find example of any of the file used as inputs or files written by this tool in the folder `examples`.
### Inputs
  All the example files are GRCh38 reference genome
1. two SEG files examples are provided;[ seg_example.seg and MMRF_1030_4.seg]
2. two files representing genomic regions [ genomic_coordinates_GRCh38_centros.bed or genomic_coordinates_GRCh38_centros_telos.bed]; the mimimum requirements is the definition of the centomeres in 
   that genomic regions file; the centromere definition is mandatory; if the telomeres are not provided, the test of checking if any segment in the seg file overlaps a telomere will not be tested; 
   if the telomeres are provided, segment overlapping the telomere by more than `th-pct-overlapping` will be excluded from the HRD score
3. To create the Karyoplots, a file with cytoband is necessary; we provide a default one for GRCh38 in the example inputs folder [grch38_ucsc_cytobands.bed]; if you use another reference genome, you MUST provide you own 
   file with the option `--karyo-file` if you want to make the plots; that file MUST follow the specs or be similar to the one provided; The option in help shows how the GRCh38 cytoband file got 
   created using UCSC table browser
  

### Outputs
tHReD outputs four (4) text files and Karytoplots when `--plots` enabled
#### text files
1. file with the HRD score
2. SEG file with segments that were used to calculate the HRD score
3. SEG file with segments that were excluded from HRD calculation because they overlap by more the X% a p or q arm
4. BED file that represents the genome territory used to calculate the HRD score

#### karyoplots
1. karyoplots with segments from the SEG input file
2. karyoplots with segments used to calculate HDR score
3. karyoplots with segments excluded from calculation but that were less than `th-log2r`

### HDR score

The HDR score is the sum of bases of filtered segments divided by the total number of bases in the new genome territory (see output file)


### NOTES

- The Example SEG file MMRF_1030_4 contains all thes use cases we can encounter for the design of current tool: segment less than 1 millions bases pair in length, segment overlapping more than 90 
  percent of an arm, gains, deletions, segments split due to centromere overlapping ... 